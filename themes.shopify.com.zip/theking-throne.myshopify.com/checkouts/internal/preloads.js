
    (function() {
      var preconnectOrigins = ["https://cdn.shopify.com"];
      var scripts = ["/cdn/shopifycloud/checkout-web/assets/c1/polyfills.Cm4XMvKf.js","/cdn/shopifycloud/checkout-web/assets/c1/app.CxMJemyf.js","/cdn/shopifycloud/checkout-web/assets/c1/2c1ab0fe.DrRCn3HG.js","/cdn/shopifycloud/checkout-web/assets/c1/6a2fc6d6.CwGUZ7Jk.js","/cdn/shopifycloud/checkout-web/assets/c1/5587f402.B-8BFOZr.js","/cdn/shopifycloud/checkout-web/assets/c1/cf29e63b.DkynDzKR.js","/cdn/shopifycloud/checkout-web/assets/c1/bfe75f31.9MQbKnYc.js","/cdn/shopifycloud/checkout-web/assets/c1/8b3289d0.8DCn8aDK.js","/cdn/shopifycloud/checkout-web/assets/c1/2255f8fa.BibYUMWp.js","/cdn/shopifycloud/checkout-web/assets/c1/204243fa.CEJ6soJp.js","/cdn/shopifycloud/checkout-web/assets/c1/5c5817f3.B7CkopGp.js","/cdn/shopifycloud/checkout-web/assets/c1/8f46f026.DB4llvax.js","/cdn/shopifycloud/checkout-web/assets/c1/f05935e5.r2uQ8ZpO.js","/cdn/shopifycloud/checkout-web/assets/c1/32e8c018.CzJHsu6N.js","/cdn/shopifycloud/checkout-web/assets/c1/7336bdaf.DTLw6J7f.js","/cdn/shopifycloud/checkout-web/assets/c1/6f2620f5.CNqIjYz0.js","/cdn/shopifycloud/checkout-web/assets/c1/b8733b27.B5rqG409.js","/cdn/shopifycloud/checkout-web/assets/c1/e39bc11c.C7Y0rIKv.js","/cdn/shopifycloud/checkout-web/assets/c1/08a3b809.BRpHAn_O.js","/cdn/shopifycloud/checkout-web/assets/c1/164ad2e3.DrLvtOSs.js","/cdn/shopifycloud/checkout-web/assets/c1/69fae6d4.B0cVlpvy.js","/cdn/shopifycloud/checkout-web/assets/c1/e12db40c.DityVWOz.js","/cdn/shopifycloud/checkout-web/assets/c1/60a453ce.DG1QMzae.js","/cdn/shopifycloud/checkout-web/assets/c1/fb3b4968.Bky-Gikg.js","/cdn/shopifycloud/checkout-web/assets/c1/f8706cb6.zdfm03X6.js","/cdn/shopifycloud/checkout-web/assets/c1/0e9ee714.ClJp1tzA.js","/cdn/shopifycloud/checkout-web/assets/c1/39921a74.D9J49Jws.js","/cdn/shopifycloud/checkout-web/assets/c1/7a8217fd.BuqZLspD.js","/cdn/shopifycloud/checkout-web/assets/c1/8599b02a.xJao-Hd4.js","/cdn/shopifycloud/checkout-web/assets/c1/dffdfb34.spQ85WMX.js","/cdn/shopifycloud/checkout-web/assets/c1/a422df8c.BHq6kDQ0.js","/cdn/shopifycloud/checkout-web/assets/c1/efa0389a.DS8XvZfk.js","/cdn/shopifycloud/checkout-web/assets/c1/c8760fd8.B9DlfYFa.js","/cdn/shopifycloud/checkout-web/assets/c1/53bbdad9.DMtlQfgP.js","/cdn/shopifycloud/checkout-web/assets/c1/1f5e7811.6Sg65osH.js","/cdn/shopifycloud/checkout-web/assets/c1/1a6c2867.DIvU9A1-.js","/cdn/shopifycloud/checkout-web/assets/c1/2fdb3dd3.CpAFg6mA.js","/cdn/shopifycloud/checkout-web/assets/c1/22345fd4.BC9B3WWT.js","/cdn/shopifycloud/checkout-web/assets/c1/0e67bd3b.DKQzvwYV.js","/cdn/shopifycloud/checkout-web/assets/c1/a9fa9fda.DvEcHzhp.js","/cdn/shopifycloud/checkout-web/assets/c1/ca3e798e.Dl0SRkiU.js","/cdn/shopifycloud/checkout-web/assets/c1/f7861534.BmTk8FK2.js","/cdn/shopifycloud/checkout-web/assets/c1/47b970b2.BcQJZH1G.js","/cdn/shopifycloud/checkout-web/assets/c1/064f6ac1.BABoWutc.js","/cdn/shopifycloud/checkout-web/assets/c1/17425706.C46b6VyD.js","/cdn/shopifycloud/checkout-web/assets/c1/71ae3d5c.COAK7VsL.js","/cdn/shopifycloud/checkout-web/assets/c1/cb5cf153.p0lPM3xl.js","/cdn/shopifycloud/checkout-web/assets/c1/06ef5503.LVYi81nB.js","/cdn/shopifycloud/checkout-web/assets/c1/acc42fa8.GtISGu1Q.js","/cdn/shopifycloud/checkout-web/assets/c1/cccd6056.fkjKd0V2.js","/cdn/shopifycloud/checkout-web/assets/c1/0b8657b8.BSrqb5EV.js","/cdn/shopifycloud/checkout-web/assets/c1/79974aab.Cn3yc8p4.js","/cdn/shopifycloud/checkout-web/assets/c1/89e2d30a.D0YTiNY7.js","/cdn/shopifycloud/checkout-web/assets/c1/ed9f2238.BddIveaH.js","/cdn/shopifycloud/checkout-web/assets/c1/6fb6f9d8.BKZ7C9Rb.js","/cdn/shopifycloud/checkout-web/assets/c1/1444e6bd.BM7R-elq.js","/cdn/shopifycloud/checkout-web/assets/c1/55098bf1.CuWaFmCR.js","/cdn/shopifycloud/checkout-web/assets/c1/f49d4216.SHqpkjWb.js","/cdn/shopifycloud/checkout-web/assets/c1/7b0c98ea.B_8hDwYl.js","/cdn/shopifycloud/checkout-web/assets/c1/d22d2b80.Be8UsXBn.js","/cdn/shopifycloud/checkout-web/assets/c1/f58f39d8.C60CzqrM.js","/cdn/shopifycloud/checkout-web/assets/c1/e03065ab.BJlkOoJe.js","/cdn/shopifycloud/checkout-web/assets/c1/c09515bf.B71fejgK.js","/cdn/shopifycloud/checkout-web/assets/c1/6bfea526.CbUOMNFh.js","/cdn/shopifycloud/checkout-web/assets/c1/ac5a19ff.Cni1qIeh.js","/cdn/shopifycloud/checkout-web/assets/c1/598fef4e.Bwzyq_hs.js","/cdn/shopifycloud/checkout-web/assets/c1/e77f7fe0.bk169rYR.js","/cdn/shopifycloud/checkout-web/assets/c1/cc6ff67d.D3tAYKR1.js","/cdn/shopifycloud/checkout-web/assets/c1/bf513f9c.CGRPQssN.js","/cdn/shopifycloud/checkout-web/assets/c1/dfca5da5.Bo5k_vWH.js","/cdn/shopifycloud/checkout-web/assets/c1/dae24aab.Ddqlep8a.js","/cdn/shopifycloud/checkout-web/assets/c1/ddf59287.CzrHQmbs.js","/cdn/shopifycloud/checkout-web/assets/c1/01973ac7.CqVjcCQ2.js","/cdn/shopifycloud/checkout-web/assets/c1/58314944.BkLOqfwy.js","/cdn/shopifycloud/checkout-web/assets/c1/945a08d6.BnKiY1Sj.js","/cdn/shopifycloud/checkout-web/assets/c1/a25deb9a.78R80re1.js","/cdn/shopifycloud/checkout-web/assets/c1/2b89a178.Cq_AXKVM.js","/cdn/shopifycloud/checkout-web/assets/c1/9068a4ed.D3CTSlX6.js","/cdn/shopifycloud/checkout-web/assets/c1/b684bff6.CwDl66gA.js","/cdn/shopifycloud/checkout-web/assets/c1/f1968089.BbrmRehk.js","/cdn/shopifycloud/checkout-web/assets/c1/910cd6e2.CL1pRsqm.js","/cdn/shopifycloud/checkout-web/assets/c1/347b440c.BMn6vhJv.js","/cdn/shopifycloud/checkout-web/assets/c1/5ade1ef3.D1oD9m5e.js","/cdn/shopifycloud/checkout-web/assets/c1/181d38d3.DX_ekfoq.js","/cdn/shopifycloud/checkout-web/assets/c1/5a347040.D5i2u6Ed.js","/cdn/shopifycloud/checkout-web/assets/c1/792bb671.XByWf7Pl.js","/cdn/shopifycloud/checkout-web/assets/c1/9ca7d819.DBJC_KDP.js","/cdn/shopifycloud/checkout-web/assets/c1/f51e663e.DtODliKi.js","/cdn/shopifycloud/checkout-web/assets/c1/21cc90a2.DHzOO82q.js","/cdn/shopifycloud/checkout-web/assets/c1/64de7b49.B6OYgKCs.js","/cdn/shopifycloud/checkout-web/assets/c1/ca0c3e72.DTdLq3jC.js","/cdn/shopifycloud/checkout-web/assets/c1/8e79be58.Mna7-MMa.js","/cdn/shopifycloud/checkout-web/assets/c1/90e26f5f.BMmA4Kw6.js","/cdn/shopifycloud/checkout-web/assets/c1/31cc568e.95lmLO5k.js","/cdn/shopifycloud/checkout-web/assets/c1/65f3d4da.Bb3QiqCm.js","/cdn/shopifycloud/checkout-web/assets/c1/d5d34b3b.BoQ1EZVF.js","/cdn/shopifycloud/checkout-web/assets/c1/ca5e9c49.Dx_ij4bq.js","/cdn/shopifycloud/checkout-web/assets/c1/f3e117aa.BS2Ire1f.js","/cdn/shopifycloud/checkout-web/assets/c1/7aefefff.v7IK9AMq.js","/cdn/shopifycloud/checkout-web/assets/c1/b3389d5c.CyCdSQig.js","/cdn/shopifycloud/checkout-web/assets/c1/73a9b0a0.BiVcTKX_.js","/cdn/shopifycloud/checkout-web/assets/c1/86720dbb.D6__U8UK.js","/cdn/shopifycloud/checkout-web/assets/c1/0724c71d.DUEOyTfc.js","/cdn/shopifycloud/checkout-web/assets/c1/7114e006.DYfOblMP.js","/cdn/shopifycloud/checkout-web/assets/c1/9babe369.ocvpn2KV.js","/cdn/shopifycloud/checkout-web/assets/c1/434e3b0a.oup8Ur0H.js","/cdn/shopifycloud/checkout-web/assets/c1/e0989459.C9WipvvF.js","/cdn/shopifycloud/checkout-web/assets/c1/cdfd59e6.BiIK8F9s.js","/cdn/shopifycloud/checkout-web/assets/c1/d2e6a587.VtVpngDC.js","/cdn/shopifycloud/checkout-web/assets/c1/ca3c8263.DhpWexJF.js","/cdn/shopifycloud/checkout-web/assets/c1/083cdde5.CzJOCrgi.js","/cdn/shopifycloud/checkout-web/assets/c1/fe885b80.hzfYrtNt.js","/cdn/shopifycloud/checkout-web/assets/c1/f78726c8.3QiE9TYQ.js","/cdn/shopifycloud/checkout-web/assets/c1/d93ca466.Bd0lEFP-.js","/cdn/shopifycloud/checkout-web/assets/c1/e129c76e.DBiXPnb_.js","/cdn/shopifycloud/checkout-web/assets/c1/051149c8.lHD9iIAq.js","/cdn/shopifycloud/checkout-web/assets/c1/d7065744.CK6x5CHa.js","/cdn/shopifycloud/checkout-web/assets/c1/7ee73f43.CLXdzDvA.js","/cdn/shopifycloud/checkout-web/assets/c1/0c0ad074.CV5n7mGR.js","/cdn/shopifycloud/checkout-web/assets/c1/8fe56fc9.Bv3QvDZY.js","/cdn/shopifycloud/checkout-web/assets/c1/2210eadb.DF0gIp_2.js","/cdn/shopifycloud/checkout-web/assets/c1/8a00b682.EmC3Jh5w.js","/cdn/shopifycloud/checkout-web/assets/c1/87bfafec.BwxqIwqz.js","/cdn/shopifycloud/checkout-web/assets/c1/e477f96c.B7RRII2U.js","/cdn/shopifycloud/checkout-web/assets/c1/c6b02d73.9b9T7YUN.js","/cdn/shopifycloud/checkout-web/assets/c1/71b60e0a.Bdvld-6t.js","/cdn/shopifycloud/checkout-web/assets/c1/24773686.C_tJhJcs.js","/cdn/shopifycloud/checkout-web/assets/c1/7048f38b.CjKh6v4D.js","/cdn/shopifycloud/checkout-web/assets/c1/c3c7c048.CHirTuvH.js","/cdn/shopifycloud/checkout-web/assets/c1/7aa3b627.DWCsBsP3.js","/cdn/shopifycloud/checkout-web/assets/c1/dada7e07.BHj3h0Lb.js","/cdn/shopifycloud/checkout-web/assets/c1/c10167e6.CHmU56DL.js","/cdn/shopifycloud/checkout-web/assets/c1/17e57de1.DrMLKbeq.js"];
      var styles = ["/cdn/shopifycloud/checkout-web/assets/c1/assets/app.DBH01810.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/is-address-empty.DDArxpAV.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/hydrate.LpOe7KaD.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/OnePage.C_uC3EPz.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/StickyPayButton.D-gNjNDa.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Switch.BS8yVgoP.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useShopPayProgressIntercepts.CIy8uDiZ.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/VatNumberValidationField.DZtuG_UK.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/EmptyState.BEvzDDvy.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Choice.BMdzfW_y.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ShopPayLogo.87JMHPUK.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ChangeCompanyLocationLink.B1YSPUDc.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PhoneField.uZEuHncj.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Popover.Bi1nHaU-.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/index.Du9dByaI.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useApplePayButtonStatus.ct4xfivv.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/TransitionHeight.CuRoM9zv.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Tipping.BcTJoNaV.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PaymentIcon.gzvCNwz_.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PaymentLine.DT05kVlY.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Section.CU18S7Ap.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/findSelectedDeliveryMethod.xO_7ctnq.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Middot.D7Ujmshx.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/EstimatedDeliveryContent.BAjucZ-8.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/BrandedPromise.B0RErzdh.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ShippingMethods.DU0m5rdF.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ShippingMethodSelector.B0hio2RO.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/SubscriptionPriceBreakdown.vTcdVGq4.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/BelowTheFoldContent.DRJckcGa.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/RememberMeSection.JBO5WNhc.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PaymentMethodProgressionHost.kQR0txJ7.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/RedirectionNotice.B8v_QGNW.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/MissingFields.BbxB_6wt.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/MobileOrderSummary.CyQZvZOO.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useOnePageFormSubmit.1WzRSowg.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/checkout-pay-button-exit.KhTiKgPS.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/observe-fit-scale.DpLOWYa8.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useShopPayButtonClassName.btyKOfco.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Payment.DrWvAMMF.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PaymentOptionSelector.s-Kd_X2E.css"];
      var fontPreconnectUrls = [];
      var fontPrefetchUrls = [];
      var imgPrefetchUrls = [];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = preconnectOrigins.concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res, next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        function run() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        }
        var next = (self.requestIdleCallback || setTimeout).bind(self, run);
        next();
      }

      function onLoaded() {
        try {
          if (parseFloat(navigator.connection.effectiveType) > 2 && !navigator.connection.saveData) {
            preconnectAssets();
            prefetchAssets();
          }
        } catch (e) {}
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  